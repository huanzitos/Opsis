<?php
$host = "localhost";
$user = "id21903934_huan";
$pass = "Huan@14052008";
$database = "id21903934_pii";
$conn = mysqli_connect($host, $user, $pass, $database);
?>